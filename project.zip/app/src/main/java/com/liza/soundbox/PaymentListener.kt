package com.liza.soundbox

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Receives real notifications from the configured Navi package only. Never creates notifications. */
class PaymentListener : NotificationListenerService() {
    private lateinit var voice: Voice
    private val seen = LinkedHashSet<String>()

    override fun onCreate() {
        super.onCreate()
        voice = Voice(this)
    }

    override fun onDestroy() {
        voice.shutdown()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != Store.pkg(this)) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val ex = n.extras
        val text = listOfNotNull(
            ex.getCharSequence(Notification.EXTRA_TITLE),
            ex.getCharSequence(Notification.EXTRA_TEXT),
            ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
        ).joinToString(" ")
        if (text.isBlank()) return

        val amt = Parser.incomingAmount(text)
        if (amt == null) {
            Store.addIgnored(this, text)
            return
        }

        val key = sbn.key + "|" + text.hashCode()
        synchronized(seen) {
            if (!seen.add(key)) return
            if (seen.size > 200) seen.remove(seen.first())
        }

        Store.addPayment(this, "LIVE", amt, "bn")
        if (Store.sound(this)) voice.announce("bn", amt)
    }
}
