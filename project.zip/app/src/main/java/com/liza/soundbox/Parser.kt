package com.liza.soundbox

/** Strict parser: only text that clearly says money came IN, with a rupee amount. */
object Parser {
    private val amount = Regex("""(?:₹|rs\.?|inr)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)
    private val incoming = listOf("received", "credited", "paid you", "sent you")
    private val reject = listOf(
        "paid to", "sent to", "debited", "failed", "declined", "request",
        "reminder", "pending", "reversed", "refund initiated", "otp"
    )

    fun incomingAmount(text: String): Double? {
        val s = text.lowercase()
        if (reject.any { s.contains(it) }) return null
        if (incoming.none { s.contains(it) }) return null
        val m = amount.find(text) ?: return null
        val v = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null
        return if (v > 0 && v < 10_000_000) v else null
    }
}
