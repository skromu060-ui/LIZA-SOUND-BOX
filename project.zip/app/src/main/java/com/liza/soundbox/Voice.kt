package com.liza.soundbox

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.UUID

class Voice(ctx: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(ctx.applicationContext, this)
    private var ready = false
    private val queue = ArrayList<() -> Unit>()

    @Volatile
    var bnOk = false
        private set

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        bnOk = t.isLanguageAvailable(Locale("bn", "IN")) >= TextToSpeech.LANG_AVAILABLE
        synchronized(queue) {
            ready = true
            queue.forEach { it() }
            queue.clear()
        }
    }

    fun announce(lang: String, amount: Double) {
        val job = { speakNow(lang, amount) }
        synchronized(queue) {
            if (!ready) {
                queue.add(job)
                return
            }
        }
        job()
    }

    private fun speakNow(lang: String, amount: Double) {
        val t = tts ?: return
        var l = lang
        var loc = Locale.forLanguageTag(Phrases.tag(l))
        if (t.isLanguageAvailable(loc) < TextToSpeech.LANG_AVAILABLE) {
            // Voice not installed: speak English so the amount is still announced.
            l = "en"
            loc = Locale.forLanguageTag("en-IN")
            if (t.isLanguageAvailable(loc) < TextToSpeech.LANG_AVAILABLE) loc = Locale.ENGLISH
        }
        t.setLanguage(loc)
        t.speak(Phrases.say(l, amount), TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
