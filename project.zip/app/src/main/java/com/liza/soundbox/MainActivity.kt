package com.liza.soundbox

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationManagerCompat

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var voice: Voice

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        voice = Voice(this)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = true
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (access()) {
            try {
                NotificationListenerService.requestRebind(ComponentName(this, PaymentListener::class.java))
            } catch (e: Exception) { }
        }
        web.evaluateJavascript("if(window.pull)pull()", null)
    }

    override fun onDestroy() {
        voice.shutdown()
        web.destroy()
        super.onDestroy()
    }

    private fun access(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun open(vararg intents: Intent) {
        runOnUiThread {
            for (i in intents) {
                try { startActivity(i); return@runOnUiThread } catch (e: Exception) { }
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun state(): String = Store.state(this@MainActivity, access(), voice.bnOk)

        @JavascriptInterface
        fun setSound(on: Boolean) { Store.setSound(this@MainActivity, on) }

        /** DEMO only: stored as source "DEMO". Real payments come only from PaymentListener. */
        @JavascriptInterface
        fun demo(amount: Double, lang: String): String {
            if (!(amount > 0 && amount < 10_000_000) || lang !in listOf("bn", "hi", "en")) return "bad"
            if (!Store.sound(this@MainActivity)) return "muted"
            val a = Math.round(amount * 100) / 100.0
            Store.addPayment(this@MainActivity, "DEMO", a, lang)
            voice.announce(lang, a)
            return "ok"
        }

        @JavascriptInterface
        fun replay(lang: String, amount: Double) {
            if (Store.sound(this@MainActivity) && lang in listOf("bn", "hi", "en")) voice.announce(lang, amount)
        }

        @JavascriptInterface
        fun clear(source: String) {
            if (source == "LIVE" || source == "DEMO") Store.clear(this@MainActivity, source)
        }

        @JavascriptInterface
        fun clearIgnored() { Store.clearIgnored(this@MainActivity) }

        @JavascriptInterface
        fun setPackage(p: String): Boolean {
            if (!Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+$").matches(p)) return false
            Store.setPkg(this@MainActivity, p)
            return true
        }

        @JavascriptInterface
        fun openAccess() = open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

        @JavascriptInterface
        fun openBattery() = open(
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )

        @JavascriptInterface
        fun openAppInfo() = open(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )

        @JavascriptInterface
        fun openTts() = open(Intent("com.android.settings.TTS_SETTINGS"), Intent(Settings.ACTION_SETTINGS))
    }
}
