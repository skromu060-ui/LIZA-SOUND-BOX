package com.liza.soundbox

object Phrases {
    fun tag(l: String) = when (l) {
        "bn" -> "bn-IN"
        "hi" -> "hi-IN"
        else -> "en-IN"
    }

    private fun bnDigits(s: String): String =
        s.map { if (it in '0'..'9') ('০' + (it - '0')) else it }.joinToString("")

    fun say(l: String, amount: Double): String {
        val total = Math.round(amount * 100)
        val r = total / 100
        val p = (total % 100).toInt()
        return when (l) {
            "bn" -> "আপনি " + bnDigits(r.toString()) + " টাকা" +
                (if (p > 0) " " + bnDigits(p.toString()) + " পয়সা" else "") + " পেয়েছেন"
            "hi" -> "आपको $r रुपये" + (if (p > 0) " $p पैसे" else "") + " प्राप्त हुए"
            else -> "You have received $r rupees" + (if (p > 0) " and $p paise" else "")
        }
    }
}
