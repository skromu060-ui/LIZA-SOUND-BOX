package com.liza.soundbox

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local-only storage. Payments carry a source: "LIVE" (real notification) or "DEMO" (test button). */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("liza", Context.MODE_PRIVATE)

    fun sound(c: Context) = p(c).getBoolean("sound", true)
    fun setSound(c: Context, on: Boolean) { p(c).edit().putBoolean("sound", on).apply() }

    fun pkg(c: Context): String = p(c).getString("pkg", "com.naviapp") ?: "com.naviapp"
    fun setPkg(c: Context, v: String) { p(c).edit().putString("pkg", v).apply() }

    private fun arr(c: Context, k: String): JSONArray =
        try { JSONArray(p(c).getString(k, "[]")) } catch (e: Exception) { JSONArray() }

    @Synchronized
    fun addPayment(c: Context, src: String, amount: Double, lang: String) {
        val old = arr(c, "hist")
        val n = JSONArray()
        n.put(JSONObject().put("s", src).put("a", amount).put("l", lang).put("t", System.currentTimeMillis()))
        for (i in 0 until minOf(old.length(), 299)) n.put(old.get(i))
        p(c).edit().putString("hist", n.toString()).apply()
    }

    @Synchronized
    fun clear(c: Context, src: String) {
        val old = arr(c, "hist")
        val n = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.getJSONObject(i)
            if (o.optString("s") != src) n.put(o)
        }
        p(c).edit().putString("hist", n.toString()).apply()
    }

    /** Notifications from the Navi app that were NOT recognised as incoming payments (kept locally, for tuning). */
    @Synchronized
    fun addIgnored(c: Context, text: String) {
        val old = arr(c, "ign")
        val n = JSONArray()
        n.put(JSONObject().put("t", System.currentTimeMillis()).put("x", text.take(160)))
        for (i in 0 until minOf(old.length(), 19)) n.put(old.get(i))
        p(c).edit().putString("ign", n.toString()).apply()
    }

    @Synchronized
    fun clearIgnored(c: Context) { p(c).edit().putString("ign", "[]").apply() }

    fun state(c: Context, access: Boolean, bn: Boolean): String =
        JSONObject()
            .put("sound", sound(c))
            .put("access", access)
            .put("bn", bn)
            .put("pkg", pkg(c))
            .put("hist", arr(c, "hist"))
            .put("ign", arr(c, "ign"))
            .toString()
}
