LIZA SOUND BOX (Android, Kotlin). Debug APK builds with: gradle assembleDebug
Live payments come only from PaymentListener (real Navi notifications). DEMO is a separate source.
